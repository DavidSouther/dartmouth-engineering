(function(){
angular.module('eau', [
  'ngMaterial',
  'eau.head-controller',
  'eau.navigation',
  // 'eau.simulation',
  // 'eau.simulation.spring',
  // 'eau.simulation.nbody',
  'eau.simulation.compression'
]);

}).call(this);

(function() {
  var l10;

  l10 = Math.log(10);

  angular.module('eau.utilities.scientific', []).filter('scientific', function() {
    return function(number, digits) {
      var exponent, len, value;
      number = '' + number;
      len = number.length;
      exponent = number.length - 1;
      value = '' + number.charAt(0);
      if (digits) {
        value += '.' + number.substr(1, digits);
      }
      value += 'e' + exponent;
      return value;
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.compression.materials', []).value('MaterialList', {
    "Granite": {
      density: 2750,
      elasticity: 10e9
    },
    "Wood": {
      density: 630,
      elasticity: 10e9
    },
    "Steel": {
      density: 7750,
      elasticity: 200
    }
  });

}).call(this);

(function() {
  var Particle, SimulationFactory;

  Particle = (function() {
    function Particle(simulation, index) {
      this.simulation = simulation;
      this.index = index;
      Object.defineProperty(this, 'position', {
        get: function() {
          return [this.simulation.positions[this.index * 2], this.simulation.positions[this.index * 2 + 1]];
        }
      });
    }

    return Particle;

  })();

  SimulationFactory = function(WorkerSvc, $rootScope, $log) {
    var Simulation;
    Simulation = (function() {
      function Simulation(N, scripts, generator) {
        var i;
        this.N = N;
        this.scripts = scripts;
        this.generator = generator;
        this.dt = 16;
        this.running = false;
        this.worker = WorkerSvc.get('/simulation/verlet.coffee');
        this.worker.addEventListener('error', (function(e) {
          return $log.error(e);
        }));
        this.worker.addEventListener('message', (function(_this) {
          return function(_arg) {
            var data, _name;
            data = _arg.data;
            return typeof _this[_name = data.event] === "function" ? _this[_name](data) : void 0;
          };
        })(this));
        this.positions = new Float64Array(this.N * 2);
        this.particles = (function() {
          var _i, _ref, _results;
          _results = [];
          for (i = _i = 0, _ref = this.N; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
            _results.push(new Particle(this, i));
          }
          return _results;
        }).call(this);
        this.reset();
        scripts.forEach((function(_this) {
          return function(path) {
            return _this.worker.postMessage({
              event: 'load',
              url: WorkerSvc.getURL(path)
            });
          };
        })(this));
      }

      Simulation.prototype.reset = function() {
        var data, event;
        this.generator.call(this);
        data = new Float64Array(this.positions);
        event = {
          event: 'reset',
          count: data.length,
          dimensions: 2,
          positions: data.buffer
        };
        return this.worker.postMessage(event, [data.buffer]);
      };

      Simulation.prototype.tick = function() {
        return this.worker.postMessage({
          event: 'tick',
          dt: this.dt
        });
      };

      Simulation.prototype.render = function(_arg) {
        var positions;
        positions = _arg.positions;
        positions = new Float64Array(positions);
        return requestAnimationFrame((function(_this) {
          return function() {
            if (_this.running) {
              _this.tick();
            }
            return $rootScope.$apply(function() {
              var i, _i, _ref, _results;
              _results = [];
              for (i = _i = 0, _ref = _this.N; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
                _this.positions[i * 2] = positions[i * 2];
                _results.push(_this.positions[i * 2 + 1] = positions[i * 2 + 1]);
              }
              return _results;
            });
          };
        })(this));
      };

      Simulation.prototype.run = function() {
        this.running = true;
        return this.tick();
      };

      Simulation.prototype.toggle = function() {
        if (this.running) {
          return this.running = false;
        } else {
          return this.run();
        }
      };

      return Simulation;

    })();
    return {
      build: function(a, b, c) {
        return new Simulation(a, b, c);
      }
    };
  };

  SimulationFactory.$inject = ['WorkerSvc', '$rootScope', '$log'];

  angular.module('eau.simulation.service', ['eau.workers']).factory('SimulationFactory', SimulationFactory);

}).call(this);

(function() {
  angular.module('eau.title-service', []).service('TitleSvc', function() {
    return {
      title: 'Engineering Around Us'
    };
  });

}).call(this);

(function() {
  var WorkerSvc;

  WorkerSvc = (function() {
    function WorkerSvc(cache) {
      this.cache = cache;
      this.workers = {};
      this.URLs = {};
    }

    WorkerSvc.prototype.getURL = function(path) {
      var blob, logic;
      if (this.URLs[path] != null) {
        return this.URLs[path];
      }
      logic = this.cache.get(path);
      blob = new Blob([logic], {
        type: 'text/javascript'
      });
      return this.URLs[path] = window.URL.createObjectURL(blob);
    };

    WorkerSvc.prototype.get = function(path) {
      var code;
      if (this.workers[path] != null) {
        return this.workers[path];
      }
      code = this.getURL(path);
      return this.workers[path] = new Worker(code);
    };

    return WorkerSvc;

  })();

  WorkerSvc.$inject = ['$workerCache'];

  angular.module('eau.workers', ['workers']).factory('$workerCache', function($cacheFactory) {
    return $cacheFactory.get('workersCache');
  }).service('WorkerSvc', WorkerSvc);

}).call(this);

(function(){
angular.module('eau.head-controller', [
  'eau.title-service'
]).controller('HeadCtrl', function($scope, TitleSvc){
  $scope.title = TitleSvc.title;
});

}).call(this);

(function() {
  angular.module('eau.simulation.compression.show-select', ['simulation.compression.show-select.template', 'ngMaterial']).controller('ShowSelectCtrl', function($scope, $mdDialog, options) {
    $scope.options = options;
    return $scope.selected = function(name) {
      return $mdDialog.hide(name);
    };
  });

}).call(this);

(function() {
  var NavigationCtrl, SimulationNav;

  SimulationNav = function($stateProvider) {
    var simlist;
    simlist = [];
    return {
      sim: function(name, args) {
        if (arguments.length === 1) {
          args = name;
        } else {
          args.name = name;
        }
        if (!args.templateUrl) {
          args.template || (args.template = "<" + args.name + " />");
        }
        simlist.push(args);
        return $stateProvider.state(args.name, {
          url: "/" + args.name,
          views: {
            "simulation": args
          }
        });
      },
      $get: function() {
        return simlist;
      }
    };
  };

  SimulationNav.$inject = ['$stateProvider'];

  NavigationCtrl = function(sims) {
    this.sims = sims;
  };

  NavigationCtrl.$inject = ['SimulationNav'];

  angular.module('eau.navigation', ['ui.router', 'navigation.template']).provider('SimulationNav', SimulationNav).controller('NavigationCtrl', NavigationCtrl).directive('navigation', function() {
    return {
      restrict: 'E',
      templateUrl: 'navigation',
      controller: 'NavigationCtrl',
      controllerAs: 'nav'
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.arch', ['eau.navigation', 'eau.simulation.arch.brick', 'simulation.arch.template']).directive('arch', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation/arch',
      scope: {
        arch: '=bricks'
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.arch.brick', ['simulation.arch.brick.template']).directive('brick', function() {
    return {
      restrict: 'E',
      replace: true,
      templateUrl: 'simulation/arch/brick',
      templateNamespace: 'svg'
    };
  });

}).call(this);

(function() {
  var GRAVITY, PI_SQUARED;

  PI_SQUARED = Math.PI * Math.PI;

  GRAVITY = 9.81;

  angular.module('eau.simulation.compression', ['eau.simulation.compression.materials', 'simulation.compression.template', 'eau.utilities.scientific', 'eau.simulation.compression.show-select', 'graphing.scales', 'graphing.svg', 'ngMaterial']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('compression', {
        title: 'Column Compression'
      });
    }
  ]).directive('compression', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation/compression',
      controller: function($scope, MaterialList, $mdDialog) {
        var s, setCurrentMaterial, _supportWeightSlide;
        setCurrentMaterial = function(materialName) {
          if (!MaterialList.hasOwnProperty(materialName)) {
            return;
          }
          return $scope.currentMaterial = {
            material: materialName,
            density: MaterialList[materialName].density,
            elasticity: MaterialList[materialName].elasticity
          };
        };
        setCurrentMaterial('Granite');
        _supportWeightSlide = 0;
        $scope.supportedWeightSlide = function(newVal) {
          var convertedVal;
          if (!angular.isDefined(newVal)) {
            return _supportWeightSlide;
          }
          convertedVal = newVal / 100;
          $scope.simulation.supported = convertedVal;
          return _supportWeightSlide = newVal;
        };
        s = $scope.simulation = {
          length: 32.2,
          tiparea: 2 * 2,
          basearea: 8 * 8,
          supported: 0
        };
        $scope.simulation.buckle = function() {
          var ba, buckle, e, l, moment;
          ba = parseFloat(s.basearea);
          l = parseFloat(s.length);
          e = $scope.currentMaterial.elasticity;
          moment = (ba * ba) / 12;
          buckle = PI_SQUARED * e * moment / (l * l);
          return buckle;
        };
        $scope.simulation.applied = function() {
          var ba, columnMass, l, supportedMass, ta, volume;
          ba = parseFloat(s.basearea);
          ta = parseFloat(s.tiparea);
          l = parseFloat(s.length);
          volume = l * (ba + ta) / 2;
          columnMass = $scope.currentMaterial.density * volume;
          supportedMass = parseFloat(s.supported);
          return (columnMass + supportedMass) * GRAVITY;
        };
        return $scope.simulation.showMaterialList = function(event) {
          var showObj;
          event.preventDefault;
          showObj = {
            templateUrl: 'simulation/compression/show-select',
            controller: 'ShowSelectCtrl',
            parent: event.target,
            hasBackdrop: false,
            clickOutsideToClose: false,
            locals: {
              options: Object.keys(MaterialList)
            }
          };
          return $mdDialog.show(showObj).then(function(materialName) {
            return setCurrentMaterial(materialName);
          });
        };
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.nbody', ['eau.simulation.service', 'simulation.template', 'eau.simulation.arch', 'graphing.scales', 'graphing.svg']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('nbody', {
        title: 'N-Body Gravity + Collisions'
      });
    }
  ]).directive('nbody', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation',
      controller: function($scope, SimulationFactory) {
        return $scope.simulation = SimulationFactory.build(20, ['/simulation/nbody/nbody.coffee'], function() {
          var i, _i, _ref, _results;
          _results = [];
          for (i = _i = 0, _ref = this.N; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
            this.positions[i * 2] = Math.random();
            _results.push(this.positions[i * 2 + 1] = Math.random());
          }
          return _results;
        });
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation', ['eau.simulation.service', 'simulation.template', 'eau.simulation.arch', 'graphing.scales', 'graphing.svg']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('falling', {
        title: 'Falling'
      });
    }
  ]).directive('falling', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation',
      controller: function($scope, SimulationFactory) {
        return $scope.simulation = SimulationFactory.build(10, ['/simulation/constraints/ground.coffee', '/simulation/forces/gravity.coffee', '/simulation/forces/bounce.coffee'], function() {
          var i, _i, _ref, _results;
          _results = [];
          for (i = _i = 0, _ref = this.N; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
            this.positions[i * 2] = Math.random();
            _results.push(this.positions[i * 2 + 1] = Math.random());
          }
          return _results;
        });
      }
    };
  });

}).call(this);

(function() {
  angular.module('eau.simulation.spring', ['eau.simulation.service', 'simulation.template', 'eau.simulation.arch', 'graphing.scales', 'graphing.svg']).config([
    'SimulationNavProvider', function(sims) {
      return sims.sim('spring', {
        title: 'Brick on a Spring'
      });
    }
  ]).directive('spring', function() {
    return {
      restrict: 'E',
      templateUrl: 'simulation',
      controller: function($scope, SimulationFactory) {
        return $scope.simulation = SimulationFactory.build(2, ['/simulation/spring/spring.coffee'], function() {
          var event, i, springList, _i, _ref;
          for (i = _i = 0, _ref = this.N; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
            this.positions[i * 2] = Math.random();
            this.positions[i * 2 + 1] = Math.random();
          }
          springList = {};
          event = {
            event: 'setSprings'
          };
          return this.worker.postMessage(event);
        });
      }
    };
  });

}).call(this);
